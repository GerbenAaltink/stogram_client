# Privit community server

## Introduction
Privit is a community server.

## Installation
```
sudo apt install python3-dev
make 
source venv/bin/activate 
privit
```