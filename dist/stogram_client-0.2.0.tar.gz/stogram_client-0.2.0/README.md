# Stogram client
Python client for the stogram pubsub server which is also located at my account. It's an async pubsub client using a custom performant json-only protocol.

